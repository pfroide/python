# -*- coding: utf-8 -*-
"""
Created on Thu Apr 12 19:42:42 2018

@author: Toni
"""

import sys
import warnings
import itertools
import pandas as pd
import numpy as np

from matplotlib import pyplot as plt
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.metrics.scorer import make_scorer
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import RidgeClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, GradientBoostingClassifier

# Pour ne pas avoir les warnings lors de la compilation
warnings.filterwarnings("ignore")

# Lieu où se trouve le fichier
if sys.platform == "windows":
    _DOSSIER = 'C:\\Users\\Toni\\Desktop\\NCoeff\\'
    _DOSSIERIMAGE = _DOSSIER + 'images\\'
    _DOSSIERCSV = _DOSSIER + 'csv\\'

elif sys.platform == "linux":
    _DOSSIER = '/home/toni/Google Drive/ncoeff/python/'
    _DOSSIERIMAGE = _DOSSIER + 'images/'
    _DOSSIERCSV = '/home/toni/Google Drive/ncoeff/data/csv/'

_FICHIER = 'dataset_foot.csv'
_LIMITE_ODD = 0.3

def scorer_x(predictions, truth):
    """
    Make_scorer permet de créer sa propre méthode d'amélioration des résultats
    """

    return np.sum((_DATA['odd_match'] - 1) * (truth == predictions)) - np.sum(truth != predictions)
    #return np.sum((datanum['odd_match'] - 1) * (truth == predictions)) - np.sum((datanum['odd_match'] - 1) * (truth != predictions))

def affichages_resultats(clf, log_cv, model):
    """
    Affichage de tous les résultats
    """

    # Nom
    print(model.__class__.__name__)

    # Affichages
    for acc, saldo, params in zip(clf.cv_results_['mean_test_accuracy'],
                                  clf.cv_results_['mean_test_saldo'],
                                  clf.cv_results_['params']):

        print("Saldo :", round(saldo, 2),
              "\tAccur :", round(acc*100, 2),
              "\tpour", params)

        # Sauvegarde des scores de predictions
        log_entry = pd.DataFrame([[saldo, acc*100, params]], columns=log_cv.columns)
        log_cv = log_cv.append(log_entry)

    # Meilleurs paramètres
    #score_max = round((clf.best_score_), 2)
    print("\nBest Saldo :", round(clf.cv_results_['mean_test_saldo'][clf.best_index_], 2),
          "\tBest Accur :" , round(100*clf.cv_results_['mean_test_accuracy'][clf.best_index_], 2),
          "\tpour", clf.best_params_, '\n')

    return log_cv

def my_accuracy(clf, X, y_true):
    """
    Scorer perso.
    Il faudra rajouter plus tard une moyenne
    """

    # Liste des résultats
    y_pred = np.array([])

    # Variable
    bon = []
    faux = []

    #df_num = pd.DataFrame()

    #print(clf.classes_)

#    for j in clf.predict_proba(X):
#        p=j.copy()
#        p.sort()
#        result = p[2]-p[1]
#
#        # C'est ici qu'on décide la limite de l'odd à choisir
#        if result > _LIMITE_ODD:
#            # On garde la proba
#            y_pred_proba = np.append(y_pred_proba, np.amax(j))
#        else:
#            # On mets 0
#            y_pred_proba = np.append(y_pred_proba, 0)

    #tableau = pd.DataFrame(clf.predict_proba(X), columns = clf.classes_)

    for j in clf.predict_proba(X):
        # C'est ici qu'on décide la limite de l'odd à choisir
        if np.amax(j) >= _LIMITE_ODD:
            # On garde le resultat
            y_pred = np.append(y_pred, clf.classes_[np.argmax(j)])
        else:
            # On mets 0
            y_pred = np.append(y_pred, 'SO')

    for j, (pred, truth) in enumerate(zip(y_pred, y_true)):
        #df_num.loc[j, 'y_pred_proba'] = prob
        #df_num.loc[j, 'y_true'] = truth

        # Si on n'a pas mis 0, on regarde si le résultat est bon
        if pred != 'SO':
            if pred == truth:
                #df_num.loc[j, 'res'] = 'bon'
                bon.append(1)
            elif pred != truth:
                #df_num.loc[j, 'res'] = 'faux'
                faux.append(1)
            else:
                print('Erreur myaccuracy')

    try:
        result = sum(bon)/(sum(bon)+sum(faux))
    except :
        if sum(bon) == 0:
            result = 0
        else:
            result = 1

    #df_num.to_csv(_DOSSIER + 'test_' + '.csv')

    return result

def my_saldo(clf, X, y_true):
    """
    Scorer perso.
    Il faudra rajouter plus tard une moyenne
    """

    # Liste des index
    y_pred_index = X.index.values

    # Liste des résultats
    y_pred = np.array([])

    #print(clf.classes_)

#    for j in clf.predict_proba(X):
#        p=j.copy()
#        p.sort()
#        result = p[2]-p[1]
#
#        # C'est ici qu'on décide la limite de l'odd à choisir
#        if result > _LIMITE_ODD:
#            # On garde la proba
#            y_pred_proba = np.append(y_pred_proba, np.amax(j))
#        else:
#            # On mets 0
#            y_pred_proba = np.append(y_pred_proba, 0)

    df_num = pd.DataFrame()

    for idx, j in zip(y_pred_index, clf.predict_proba(X)):
        df_num.loc[idx, 'max'] = np.amax(j)
        df_num.loc[idx, 'odd'] = _DATA.loc[idx, 'odd_match']
        # C'est ici qu'on décide la limite de l'odd à choisir
        if np.amax(j) >= _LIMITE_ODD:
            # On garde la proba
            y_pred = np.append(y_pred, clf.classes_[np.argmax(j)])
        else:
            # On mets 0
            y_pred = np.append(y_pred, 'SO')

    # Variable
    odd = 0.0

    liste = []
    liste_faux = []

    for pred, idx, truth in zip(y_pred, y_pred_index, y_true):
        df_num.loc[idx, 'y_pred_proba'] = pred
        df_num.loc[idx, 'y_true'] = truth

        # Si on n'a pas mis 0, on regarde si le résultat est bon
        if pred != 'SO':
            if pred == truth:
                df_num.loc[idx, 'res'] = 'bon'
                # On ne fait pas le calcul directement à cause des NaN
                liste.append(_DATA.loc[idx, 'odd_match'])
            elif pred != truth:
                df_num.loc[idx, 'res'] = 'faux'
                liste_faux.append(1)
                #odd = odd - 1
            else:
                print('Erreur mysaldo')

    odd = np.nansum(liste) - len(liste) - len(liste_faux)

    #df_num.to_csv(_DOSSIER + clf.__class__.__name__ + '.csv')
    #df_num.to_csv(_DOSSIER + clf.__class__.__name__ + str(clf.n_neighbors) + '.csv')

    return odd

def definir_importance(xdata):
    """
        Fonction qui permet d'afficher un graphique
        où l'on verra l'importance relative de chaque élément dans le calcul
        final
    """

    # Séparation des étiquettes
    xdata = xdata.fillna(0)
    ydata = xdata['FTR']

    # Suppression de lignes
    del xdata['FTR']
    del xdata['HomeTeam']
    del xdata['AwayTeam']
    del xdata['Div']
    del xdata['odd_match']

    names = xdata.columns.values

    # Build the model
    rfc = RandomForestClassifier(n_estimators=1000,
                                 criterion='gini',
                                 verbose=0)

    # Fit the model
    rfc.fit(xdata, ydata)

    # Print the results
    print("Features sorted by their score:")
    print(sorted(zip(map(lambda x: round(x, 4), rfc.feature_importances_), names), reverse=True))

    # Isolate feature importances
    importance = rfc.feature_importances_

    # Sort the feature importances
    sorted_importances = np.argsort(importance)

    # Insert padding
    padding = np.arange(len(names)) + 0.5

    # Customize the plot
    plt.figure(figsize=(10, 6))
    plt.yticks(padding, names[sorted_importances])
    plt.xlabel("Relative Importance")
    plt.title("Variable Importance")

    # Plot the data
    plt.barh(padding, importance[sorted_importances], align='center')
    plt.grid()
    plt.tight_layout()
    plt.savefig(_DOSSIERIMAGE + "relative_importance")

    # Show the plot
    plt.show()

def plot_confusion_matrix(conf_matrix, classes, title, division):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """

    # Taille de la figure
    np.set_printoptions(precision=2)
    plt.figure(figsize=(5, 5))

    # Jeu de couleur
    cmap = plt.cm.Blues

    # Normalize
    #conf_matrix = conf_matrix.astype('float') / conf_matrix.sum(axis=1)[:, np.newaxis]

    plt.imshow(conf_matrix, interpolation='nearest', cmap=cmap)
    title = division + "_Matrix_" + title
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes)
    plt.yticks(tick_marks, classes)

    fmt = 'd' #'.2f'
    thresh = conf_matrix.max() / 2.
    for i, j in itertools.product(range(conf_matrix.shape[0]), range(conf_matrix.shape[1])):
        plt.text(j, i, format(conf_matrix[i, j], fmt),
                 horizontalalignment="center",
                 color="white" if conf_matrix[i, j] > thresh else "black")

    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.tight_layout()
    plt.savefig(_DOSSIERIMAGE + title)
    plt.show()

def algos_cv(xtrain, ytrain, xtest, ytest, model, param_grid, division):
    """
    TBD
    """

    # Score à améliorer
    saldo = make_scorer(scorer_x,
                        greater_is_better=True,
                        needs_threshold=False)

    scoring = {'saldo': saldo,
               'accuracy': 'accuracy'}

    # Options de l'algorithme
    clf = GridSearchCV(model,
                       param_grid=param_grid,
                       verbose=0,
                       cv=3,
                       scoring=scoring,
                       refit='saldo',
                       return_train_score=False)

    # Fit
    clf.fit(xtrain, ytrain)

    # Liste qui va garder les résultats
    log_cols = ["Saldo", "Accuracy", "Params"]
    log_cv = pd.DataFrame(columns=log_cols)

    # Affichage des données chiffrées
    log_cv = affichages_resultats(clf, log_cv, model)

    # Affichage du diagramme en baton
    affichage_batons(model, log_cv, division, 'normal')

    # Affichage de la matrice de confusion
    #ypred = clf.best_estimator_.predict(xtest)
    #cnf_matrix = confusion_matrix(ypred, ytest, labels=ytrain.unique())
    #plot_confusion_matrix(cnf_matrix, ytest.unique(), model.__class__.__name__, division)

def affichage_batons(model, log_cv, division, version):
    """
    Diagrammes en batons pour voir les résultats
    """

    # Mise en forme légère
    log_cv = log_cv.reset_index()
    del log_cv['index']

    # Noms des variables
    data_colonne1 = log_cv['Saldo']
    data_colonne2 = log_cv['Accuracy']
    data_ligne = log_cv['Params']

    # La figure change de taille suivant le nombre de données
    fig = plt.figure(figsize=(len(data_ligne), 12))
    ax1 = fig.add_subplot(111)
    ax2 = ax1.twinx()

    # Données de l'axe X
    x_axis = [k for k, i in enumerate(data_colonne1)]
    x_axis = np.arange(0, len(x_axis))
    x_label = [i for i in data_ligne]

    # Données de l'axe Y
    y_axis1 = [i for i in data_colonne1]
    y_axis2 = [i for i in data_colonne2]

    # Limite de l'axe Y
    #ax1.set_ylim(min(log_cv['Saldo'])-20, max(log_cv['Saldo'])+20)
    #ax2.set_ylim(min(log_cv['Accuracy'])-20, max(log_cv['Accuracy'])+20)
    ax1.set_ylim(min(log_cv['Saldo'])-20, max(log_cv['Accuracy'])+20)
    ax2.set_ylim(min(log_cv['Saldo'])-20, max(log_cv['Accuracy'])+20)
    # Largeur des barres
    width = 0.2

    # Création
    rects = ax1.bar(x_axis-0.1, y_axis1, width, color='b', align='center')

    # On fait les labels pour les afficher
    labels = ["%.1f" % i for i in data_colonne1]

    for rect, label in zip(rects, labels):
        height = rect.get_height()
        # Suivant le signe, on décale un peu le texte
        height = (height+0.5) if '-' not in label else (height-3)
        width = rect.get_width()

        ax1.text(rect.get_x()+(width/2)-0.2,
                 height,
                 label,
                 ha='center',
                 va='bottom',
                 color='b')

    # Création
    rects = ax2.bar(x_axis+0.1, y_axis2, width, color='r', align='center')

    # On fait les labels pour les afficher
    labels = ["%.1f" % i for i in data_colonne2]

    for rect2, label in zip(rects, labels):
        height = rect2.get_height()
        # Suivant le signe, on décale un peu le texte
        height = (height+0.5) if '-' not in label else (height-3)
        width = rect2.get_width()

        ax2.text(rect2.get_x()+(width/2)+0.2,
                 height,
                 label,
                 ha='center',
                 va='bottom',
                 color='r')

    # Esthétisme
    ax1.grid()
    ax1.set_ylabel('Saldo', color='b')
    ax1.tick_params(colors='b')

    ax2.set_ylabel('Accuracy', color='r')
    ax2.tick_params(colors='r')

    # Légende de l'axe X
    ax1.set_xticks(x_axis)
    ax1.set_xticklabels(x_label, minor=False, rotation=90, color='black')

    titre = version + '_' + division + '_Saldo_' + model.__class__.__name__
    ax1.set_title(titre)

    fig.tight_layout()
    fig.savefig(_DOSSIERIMAGE + titre)
    fig.show()

def appel_cvs(xtrain, xtest, ytrain, ytest, division):
    """
    Fonction qui fournit les hyperparamètres aux modèles et appelle les fonctions
    """

    from sklearn.naive_bayes import MultinomialNB

    # Choix de l'algorithme de classification
    model = [KNeighborsClassifier(),
             RandomForestClassifier(),
             GradientBoostingClassifier(),
             #DecisionTreeClassifier(),
             #RidgeClassifier(),
             LogisticRegression(),
             LogisticRegression(),
             MultinomialNB()
            ]

    # Hyperparamètres
    param_grid = [{'n_neighbors': [3, 7, 15, 30, 50, 100, 500]},
                  {'max_depth': [None, 20, 35, 50, 65, 80, 110, 200],
                   'n_estimators': [5, 20, 35, 50, 65, 80, 110, 200]},
                  {'max_depth': [None, 10, 20, 40, 70, 90, 120, 150],
                   'n_estimators': [5, 20, 35, 50, 65, 80, 95, 110]},
                  #{'criterion': ['gini', 'entropy'],
                  # 'max_depth':[None, 10, 20, 40, 70, 90, 120, 150]},
                  #{'alpha': np.logspace(-7, 7, 15)},
                  {'penalty': ['l1'],
                   'C': [0.001, 0.01, 0.1, 1, 10, 100, 1000],
                   'class_weight' : [None, 'balanced'],
                   'solver' : ['liblinear', 'saga']},
                  {'penalty': ['l2'],
                   'C': [0.001, 0.01, 0.1, 1, 10, 100, 1000],
                   'class_weight' : [None, 'balanced'],
                   'solver' : ['newton-cg', 'lbfgs', 'sag']},
                  {'alpha': [0.001, 0.01, 0.1, 1, 10, 100, 1000],
                   'fit_prior': [True, False]}
                 ]

    # Appel de fonction
    for i in enumerate(model):
        algos_cv(xtrain, ytrain, xtest, ytest, model[i[0]], param_grid[i[0]], division)
        proba_cv(xtrain, ytrain, xtest, ytest, model[i[0]], param_grid[i[0]], division)

def lancer_algorithme(datanum):
    """
    Fonction de calcul pour tous les algorithmes différents pour chaque compagnie
    """

    # Création de la liste (unique) des compagnies aériennes
    liste = datanum['Div'].unique()

    liste = ['E0', 'P1']

    for division in liste:

        # Axe X
        data_x = datanum.copy()

        print('\nPour la division', division, '\n')

        # On ne garde que les données pour 1 compagnie à la fois
        data_x = data_x[data_x['Div'] == division]

        # Axe Y
        data_y = data_x['FTR'].copy()

        # On supprime les étiquettes de l'axe X
        liste_suppression = ['FTR',
                             'Div',
                             'odd_match',
                             'HomeTeam',
                             'AwayTeam'
                            ]

        for colon in liste_suppression:
            if colon in data_x:
                del data_x[colon]

        # On supprime les nan
        data_x.fillna(0, inplace=True)
        data_y.fillna(0, inplace=True)

        # Répartition Train/Test
        xtrain, xtest, ytrain, ytest = train_test_split(data_x, data_y, train_size=0.8)

        # Fonction qui permets de faire les CV
        appel_cvs(xtrain, xtest, ytrain, ytest, division)

def proba_cv(xtrain, ytrain, xtest, ytest, model, param_grid, division):
    """
    Version probabiliste
    Fonction qui fournit les hyperparamètres aux modèles et appelle les fonctions
    """

    scoring = {'saldo': my_saldo,
               'accuracy': my_accuracy}

    clf = GridSearchCV(estimator=model,
                       param_grid=param_grid,
                       cv=3,
                       scoring=scoring,
                       refit='saldo',
                       return_train_score=False
                      )

    clf.fit(xtrain, ytrain)

    # Liste qui va garder les résultats
    log_cols = ["Saldo", "Accuracy", "Params"]
    log_cv = pd.DataFrame(columns=log_cols)

    # Affichage des données chiffrées
    log_cv = affichages_resultats(clf, log_cv, model)

    # Affichage du diagramme en baton
    affichage_batons(model, log_cv, division, 'proba')

    # Affichage de la matrice de confusion
    #ypred = clf.best_estimator_.predict(xtest)
    #cnf_matrix = confusion_matrix(ypred, ytest, labels=ytrain.unique())
    #plot_confusion_matrix(cnf_matrix, ytest.unique(), model.__class__.__name__, division)

def main():
    """
    Fonction principale
    """

    global _DATA

    # Récupération des dataset
    _DATA = pd.read_csv(_DOSSIER + _FICHIER,
                        error_bad_lines=False,
                        low_memory=False,
                        encoding='ascii')

    #_DATA = _DATA[_DATA['odd_match'] > 1.5]
    _DATA = _DATA[_DATA['odd_match'] < 2]

    #print(_DATA.shape)
    #_DATA = _DATA[_DATA['BbAvA'] > 1.9]
    #_DATA = _DATA[_DATA['BbAvH'] > 1.9]
    #_DATA = _DATA[_DATA['BbAvD'] > 1.9]

    #_DATA = _DATA[_DATA['BbAvA'] < 1.9]
    #_DATA = _DATA[_DATA['BbAvH'] < 1.9]
    #_DATA = _DATA[_DATA['BbAvD'] < 1.9]
    #print(_DATA.shape)

    # Suppression de colonnes
    del _DATA['Unnamed: 0']
    del _DATA['Year']
    del _DATA['Month']
    #del _DATA['BbAvH']
    #del _DATA['BbAvD']
    #del _DATA['BbAvA']

    # Copie de sauvegarde
    datanum = pd.DataFrame()
    datanum = _DATA.copy()

    # Voir l'importance des variables
    #definir_importance(datanum)

    # Lancer l'algorithme
    lancer_algorithme(datanum)
