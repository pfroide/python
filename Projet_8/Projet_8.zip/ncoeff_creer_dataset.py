# -*- coding: utf-8 -*-
"""
Created on Sat May 12 20:55:16 2018

@author: Toni
"""

import os
import sys
import warnings
import datetime
import pandas as pd
import numpy as np

# Pour ne pas avoir les warnings lors de la compilation
warnings.filterwarnings("ignore")

# Lieu où se trouve le fichier
if sys.platform == "windows":
    _DOSSIER = 'C:\\Users\\Toni\\Desktop\\NCoeff\\'
    _DOSSIERCSV = _DOSSIER + 'csv\\'

elif sys.platform == "linux":
    _DOSSIER = '/home/toni/Google Drive/ncoeff/python/'
    _DOSSIERCSV = '/home/toni/Google Drive/ncoeff/data/csv/'

def main():
    """
    Fonction principale
    """

    # Récupération des dataset
    data = pd.DataFrame()

    for i, element in enumerate(os.listdir(_DOSSIERCSV)):
        if element.endswith('.csv'):
            datatemp = pd.read_csv(_DOSSIERCSV + element,
                                   error_bad_lines=False,
                                   low_memory=False,
                                   encoding='ascii')

            datatemp['id'] = i
            data = pd.concat([data, datatemp])

    # Formatage des espaces inutiles avec rstrip
    data['HomeTeam'] = data['HomeTeam'].str.rstrip()
    data['AwayTeam'] = data['AwayTeam'].str.rstrip()

    subsetlist = ['Div', 'HomeTeam', 'AwayTeam',
                  'HS', 'AS', 'HST', 'AST', 'HHW', 'AHW',
                  'HC', 'AC', 'HF', 'AF', 'HFKC', 'AFKC',
                  'HO', 'AO', 'HY', 'AY', 'HR', 'AR', 'FTR',
                  'BbAvH', 'BbAvD', 'BbAvA', 'FTHG', 'FTAG']

    data = data.drop_duplicates(subset=subsetlist, keep='first')
    data = data.reset_index(drop=True)

    # Liste des colonnes que l'on va garder
    liste_a_garder = subsetlist.copy()
    liste_a_garder.append('Date')
    liste_a_garder.append('id')

    for colon in data:
        if colon not in liste_a_garder:
            del data[colon]

    data.dropna(subset=['Date', 'Div', 'FTR', 'AwayTeam', 'HomeTeam'],
                axis=0,
                how='any',
                inplace=True)

    # Copie de travail
    df_num = data.copy()

    # Création des dates
    creer_dates(df_num)
    df_num = df_num.sort_values(by='datetime_Date')
    df_num = df_num.reset_index(drop=True)

    # Compter les nombres de buts, à améliorer
    df_buts, df_champ = creer_sommes(df_num)

    # Création des bonnes colonnes
    creer_stats(df_num, df_champ, df_buts)

    # Suppression de la date au format complet, inutile à priori
    del df_num['datetime_Date']
    del df_num['id']

    # Rajout des odds pour le saldo
    df_num = df_num.reset_index(drop=True)
    for i in range(0, len(df_num)):
        if df_num.loc[i, 'FTR'] == 'D':
            df_num.loc[i, 'odd_match'] = df_num.loc[i, 'BbAvD']
        elif df_num.loc[i, 'FTR'] == 'A':
            df_num.loc[i, 'odd_match'] = df_num.loc[i, 'BbAvA']
        elif df_num.loc[i, 'FTR'] == 'H':
            df_num.loc[i, 'odd_match'] = df_num.loc[i, 'BbAvH']

    # Export
    df_num.to_csv(_DOSSIER + 'dataset_foot.csv')

def creer_sommes(df_num):
    """
    TBD
    """

    # DataFrame vide
    df_temp = pd.DataFrame()

    # Pour toutes les équipes, on recherche les stats :
    # Buts et nb matchs à domicile
    # Buts et nb matchs à l'extérieur
    for equipe in df_num['HomeTeam'].unique():
        # Domicile
        # Récupération des données à domicile
        test_home = df_num[df_num['HomeTeam'] == equipe]

        # Aggrégation :
        # nombre de buts à domicile
        # nombre de buts à l'extérieur
        # nombre de matchs dans l'année pour l'équipe Home
        agg_home = {'FTHG':'sum', 'FTAG':'sum', 'HomeTeam':'count'}
        dt_home = test_home.groupby(['id', 'HomeTeam']).agg(agg_home)

        # Rennomage des colonnes
        dt_home = dt_home.rename(columns={'FTHG':'FTHG_POUR',
                                          'FTAG':'FTHG_CONTRE'})

        # Extérieur
        test_away = df_num[df_num['AwayTeam'] == equipe]
        agg_away = {'FTHG':'sum', 'FTAG':'sum', 'AwayTeam':'count'}
        dt_away = test_away.groupby(['id', 'AwayTeam']).agg(agg_away)
        dt_away = dt_away.rename(columns={'FTAG':'FTAG_POUR',
                                          'FTHG':'FTAG_CONTRE'})

        # On agrège les résultats au fur et à mesure
        dta = pd.concat([dt_home, dt_away], axis=1)
        df_temp = pd.concat([df_temp, dta])

    # Correspondance id/year
    correspondance = df_num.groupby(['id']).agg({'Year':min})

    # Changement de noms des colonnes initiales
    df_temp = df_temp.rename(columns={'HomeTeam': 'HomeTeamMatchs',
                                      'AwayTeam': 'AwayTeamMatchs'})

    # On supprime l'index existant -> 2 colonnes avec les valeurs
    df_temp = df_temp.reset_index()
    df_temp['Year'] = df_temp['id']

    # On remplace par la correspondance id/year
    df_temp['Year'].replace(correspondance.index, correspondance['Year'], inplace=True)

    # Formattage en entier
    df_temp['Year'] = df_temp['Year'].astype(int)

    # Changement de noms des colonnes initiales
    df_temp = df_temp.rename(columns={'Year': 'Champ',
                                      'HomeTeam': 'Team'})

    # Pour tous les championnats, on cherche les stats :
    # nombre de buts à domicile
    # nombre de buts à l'extérieur
    # nombre de matchs dans l'année
    aggregations = {'FTHG':'sum',
                    'FTAG':'sum',
                    'Year':min,
                    'HomeTeam':'count'
                   }

    df_total = df_num.groupby(['id', 'Div']).agg(aggregations).reset_index()
    df_total = df_total.rename(columns={'Year': 'Champ',
                                        'HomeTeam': 'Total_games'})

    return df_temp, df_total

def creer_dates(df_num):
    """
    Fonction pour créer des dates à partir du format initial
    """

    # Format Datetime
    # list comprehension
    # [ expression for item in list if conditional ]
    # [x+1 if x >= 45 else x+5 for x in l]
    df_num['datetime_Date'] = [datetime.datetime.strptime(x, '%d/%m/%y') \
                               if len(x) == 8 \
                               else datetime.datetime.strptime(x, '%d/%m/%Y') \
                               for x in df_num['Date']]

    # Suppresion de la date au format initial
    del df_num['Date']

    # Jour de la semaine du match
    df_num['Weekday'] = [x for x in df_num['datetime_Date'].dt.weekday]

    # Mois du match
    df_num['Month'] = [x for x in df_num['datetime_Date'].dt.month]

    # Année du match
    df_num['Year'] = [x for x in df_num['datetime_Date'].dt.year]

def creer_stats(df_num, df_champ, df_buts):
    """
    Création du dataset

    HS = Home Team Shots
    AS = Away Team Shots
    HST = Home Team Shots on Target
    AST = Away Team Shots on Target
    HHW = Home Team Hit Woodwork
    AHW = Away Team Hit Woodwork
    HC = Home Team Corners
    AC = Away Team Corners
    HF = Home Team Fouls Committed
    AF = Away Team Fouls Committed
    HFKC = Home Team Free Kicks Conceded
    AFKC = Away Team Free Kicks Conceded
    HO = Home Team Offsides
    AO = Away Team Offsides
    HY = Home Team Yellow Cards
    AY = Away Team Yellow Cards
    HR = Home Team Red Cards
    AR = Away Team Red Cards
    HBP = Home Team Bookings Points (10 = yellow, 25 = red)
    ABP = Away Team Bookings Points (10 = yellow, 25 = red)
    """

    # Nombre de journées à prendre en compte
    nb_forme = 5

    # Nombre de jours pour compter les matchs
    nb_jour = 15
    time_lapse = datetime.timedelta(days=nb_jour)

    listing_home = ['HS', 'HST', 'HC', 'HF',
                    'HY', 'HR', 'FTHG', 'HO', 'HHW'
                   ]

    listing_away = ['AS', 'AST', 'AC', 'AF',
                    'AY', 'AR', 'FTAG', 'AO', 'AHW'
                   ]

    listing_nom = ['shots', 'shots_target',
                   'corners', 'fouls',
                   'yellow', 'red', 'goals', 'offsides', 'shots_wood'
                  ]

    listing_manuel = ['HomeTeamMatchs', 'AwayTeamMatchs',
                      'buts_POUR_equipe_home', 'buts_POUR_equipe_away',
                      'buts_CONTRE_equipe_home', 'buts_CONTRE_equipe_away',
                      'buts_championnat_home', 'buts_championnat_away', 'championnat_nbmatchs'
                     ]

    for equipe in df_num['HomeTeam'].unique():
        # Compteur d'erreurs
        nb_erreurs = 0

        # Affichage
        print(equipe, 'en cours...')

        # Création du dataset temporaire pour chaque équipe
        temp = df_num[np.logical_or(df_num['HomeTeam'] == equipe, df_num['AwayTeam'] == equipe)]

        # Suppression des lignes qui seraient en double
        temp = temp.drop_duplicates(keep='first')

        # Dataset vierge
        df_complete = pd.DataFrame()

        # Pour toutes les lignes du dataset temporaire, on prends les stats Away ou Home
        for i in range(0, len(temp)):
            for l_home, l_away, l_nom in zip(listing_home, listing_away, listing_nom):
                try:
                    df_complete.loc[i, l_nom] = temp.loc[temp.index[i], l_home] \
                        if temp.loc[temp.index[i], 'HomeTeam'] == equipe \
                        else temp.loc[temp.index[i], l_away]
                except:
                    nb_erreurs += 1

        # Pour toutes les lignes à partir de la n°nbj, on fait les sommes
        for i in range(nb_forme, len(df_complete)):
            #print(i, temp.loc[temp.index[i], 'HomeTeam'])
            for l_nom in listing_nom:

                # Pour l'équipe à domicile
                if temp.loc[temp.index[i], 'HomeTeam'] == equipe:
                    nom_colon = 'home_last_5_' + l_nom

                # Pour l'équipe à l'extérieur
                else:
                    nom_colon = 'away_last_5_' + l_nom

                try:
                    df_complete.loc[i, nom_colon] = df_complete[i-nb_forme: i][l_nom].sum()
                except:
                    nb_erreurs += 1

        # Partie 1 du calcul des expecteds goals
        df_complete, nb_erreurs = expected_goals(df_champ,
                                                 df_buts,
                                                 df_complete,
                                                 equipe,
                                                 temp,
                                                 nb_erreurs)

        # Comptage du nombre de matchs
        df_complete, nb_erreurs = comptage_nombre_maths(df_complete,
                                                        temp,
                                                        equipe,
                                                        nb_erreurs,
                                                        time_lapse)

        # Copier-coller des index
        df_complete.index = temp.index

        # Rajout des dates dans la liste pour qu'elle soit complète
        listing_nom.append('games_per_15')

        # Pour tous les index du dataset créé, on récopie les valeurs dans le dataset initial
        for i in df_complete.index:
            for l_nom in listing_nom:
                if df_num.loc[i, 'HomeTeam'] == equipe:
                    if l_nom != 'games_per_15':
                        nom_colon = 'home_last_5_' + l_nom
                    else:
                        nom_colon = 'home_' + l_nom
                else:
                    if l_nom != 'games_per_15':
                        nom_colon = 'away_last_5_' + l_nom
                    else:
                        nom_colon = 'away_' + l_nom

                try:
                    df_num.loc[i, nom_colon] = df_complete.loc[i, nom_colon]
                except:
                    nb_erreurs += 1

            # c'est la que ça merde ?
            for nom_colon in listing_manuel:
                try:
                    if pd.notna(df_complete.loc[i, nom_colon]):
                        df_num.loc[i, nom_colon] = df_complete.loc[i, nom_colon]
                except:
                    nb_erreurs += 1

        # Rajout des dates dans la liste pour qu'elle soit complète
        listing_nom.remove('games_per_15')

        print('... avec', nb_erreurs, 'erreur(s)')

    # Suppression des journées qui ne sont pas complètes
    df_num.dropna(subset=['home_last_5_goals', 'away_last_5_goals'],
                  axis=0,
                  how='any',
                  inplace=True)

    # Partie 2 du calcul des expecteds goals
    df_num = strength(df_num)

    # Suppression des colonnes d'origine
    for colon in df_num:
        if colon in listing_home or colon in listing_away or colon in listing_manuel:
            del df_num[colon]

def expected_goals(df_champ, df_buts, df_complete, equipe, temp, nb_erreurs):
    """
    How to calculate Attack Strength

    The first step in calculating Attack Strength based upon last season’s results
    is to determine the average number of goals scored per team, per home game,
    and per away game.

    Calculate this by taking the total number of goals scored last season and
    dividing it by the number of games played:

        Season total goals scored at home / number of games (in season)
        Season total goals scored away / number of games (in season)

    In 2015/16 English Premier League season,
    there were 567/380 at home and 459/380 away,
    equalling an average of 1.492 goals per game at home and 1.207 away.

        Average number of goals scored at home: 1.492
        Average number of goals scored away: 1.207

    The ratio of a team's average and the league average is what constitutes “Attack Strength”.

    How to calculate Defence Strength

    We’ll also need the average number of goals an average team concedes.
    This is simply the inverse of the above numbers (as the number of goals a
    home team scores will equal the same number that an away team concedes):

        Average number of goals conceded at home: 1.207
        Average number of goals conceded away from home: 1.492

    The ratio of a team's average and the league average is what constitutes "Defence Strength".

    We can now use the numbers above to calculate the Attack Strength
    and Defence Strength of both Tottenham Hotspur and Everton (as of 1st March 2017).
    """

    for i in range(0, len(temp)):
        # Recherche de l'id du championnat
        id_champ = temp.loc[temp.index[i], 'id']

        # Recherche de l'année du championnat
        annee = df_champ['Champ'][df_champ['id'] == id_champ].reset_index().loc[0, 'Champ']

        # Recherche de la division
        division = df_champ['Div'][df_champ['id'] == id_champ].reset_index().loc[0, 'Div']

        # Id du championnat n-1
        try:
            # Nouveau Id du championnat n-1
            new_id = df_champ['id'][(df_champ['Div'] == division) & (df_champ['Champ'] == annee-1)].reset_index().loc[0, 'id']

            # Buts totaux du championnat
            df_complete.loc[i, 'buts_championnat_home'] = df_champ['FTHG'][df_champ['id'] == new_id].reset_index().loc[0, 'FTHG']
            df_complete.loc[i, 'buts_championnat_away'] = df_champ['FTAG'][df_champ['id'] == new_id].reset_index().loc[0, 'FTAG']
            df_complete.loc[i, 'championnat_nbmatchs'] = df_champ['Total_games'][df_champ['id'] == new_id].reset_index().loc[0, 'Total_games']

            if temp.loc[temp.index[i], 'HomeTeam'] == equipe:
                # Nombre de matchs de l'équipe
                var = df_buts['HomeTeamMatchs'][(df_buts['id'] == new_id) & (df_buts['Team'] == equipe)].reset_index().loc[0, 'HomeTeamMatchs']
                df_complete.loc[i, 'HomeTeamMatchs'] = var

                # Buts de l'équipe
                var = df_buts['FTHG_POUR'][(df_buts['id'] == new_id) & (df_buts['Team'] == equipe)].reset_index().loc[0, 'FTHG_POUR']
                df_complete.loc[i, 'buts_POUR_equipe_home'] = var

                # Buts contre l'équipe
                var = df_buts['FTHG_CONTRE'][(df_buts['id'] == new_id) & (df_buts['Team'] == equipe)].reset_index().loc[0, 'FTHG_CONTRE']
                df_complete.loc[i, 'buts_CONTRE_equipe_home'] = var

            else:
                # Nombre de matchs de l'équipe
                var = df_buts['AwayTeamMatchs'][(df_buts['id'] == new_id) & (df_buts['Team'] == equipe)].reset_index().loc[0, 'AwayTeamMatchs']
                df_complete.loc[i, 'AwayTeamMatchs'] = var

                # Buts de l'équipe
                var = df_buts['FTAG_POUR'][(df_buts['id'] == new_id) & (df_buts['Team'] == equipe)].reset_index().loc[0, 'FTAG_POUR']
                df_complete.loc[i, 'buts_POUR_equipe_away'] = var

                # Buts contre l'équipe
                var = df_buts['FTAG_CONTRE'][(df_buts['id'] == new_id) & (df_buts['Team'] == equipe)].reset_index().loc[0, 'FTAG_CONTRE']
                df_complete.loc[i, 'buts_CONTRE_equipe_away'] = var
        except:
            nb_erreurs += 1

    return df_complete, nb_erreurs

def comptage_nombre_maths(df_complete, temp, equipe, nb_erreurs, time_lapse):
    """
    Comptage du nombre de matchs
    """

    for i in range(0, len(df_complete)):

        # Pour l'équipe à domicile
        if temp.loc[temp.index[i], 'HomeTeam'] == equipe:
            nom_colon = 'home_games_per_15'

        # Pour l'équipe à l'extérieur
        else:
            nom_colon = 'away_games_per_15'

        try:
            df_complete.loc[i, nom_colon] = \
                temp['FTR'][(temp.loc[temp.index[i], 'datetime_Date'] > temp.datetime_Date - time_lapse) & \
                (temp.loc[temp.index[i], 'datetime_Date'] < temp.datetime_Date + time_lapse)].count()
        except:
            nb_erreurs += 1

    return df_complete, nb_erreurs

def strength(df_temp):
    """
    TBD
    """

    for i in range(0, len(df_temp)):
        try:
            # Hometeam
            # Take the number of goals scored at home last season by the home team
            # and divide by the number of home games (35/19): 1.842.
            attack = df_temp.loc[i, 'buts_POUR_equipe_home'] / df_temp.loc[i, 'HomeTeamMatchs']

            # Divide this value by the season’s average home goals
            # scored per game (1.842/1.492) to get an “Attack Strength” of 1.235.
            attack = attack / (df_temp.loc[i, 'buts_championnat_home'] / df_temp.loc[i, 'championnat_nbmatchs'])

            # Awayteam
            # Take the number of goals conceded away from last season by the away
            # team (Everton: 25) and divide by the number of away games (25/19): 1.315.
            defense = df_temp.loc[i, 'buts_CONTRE_equipe_away'] / df_temp.loc[i, 'AwayTeamMatchs']

            # Divide this by the season’s average goals conceded by an away team per
            # game (1.315/1.492) to get a “Defence Strength” of 0.881.
            defense = defense / (df_temp.loc[i, 'buts_championnat_home'] / df_temp.loc[i, 'championnat_nbmatchs'])

            # We can now use the following formula to calculate the likely number
            # of goals Tottenham might score (this is done by multiplying
            # Tottenham's Attack Strength by Everton's Defence Strength and the
            # average number of home goals in the Premier League):
            # 1.235 x 0.881 x 1.492 = 1.623
            df_temp.loc[i, 'xG_Home'] = attack * defense * (df_temp.loc[i, 'buts_championnat_home'] / df_temp.loc[i, 'championnat_nbmatchs'])

            # Pareil, mais avec l'équipe exterieur
            attack = df_temp.loc[i, 'buts_POUR_equipe_away'] / df_temp.loc[i, 'AwayTeamMatchs']
            attack = attack / (df_temp.loc[i, 'buts_championnat_away'] / df_temp.loc[i, 'championnat_nbmatchs'])
            defense = df_temp.loc[i, 'buts_CONTRE_equipe_home'] / df_temp.loc[i, 'HomeTeamMatchs']
            defense = defense / (df_temp.loc[i, 'buts_championnat_away'] / df_temp.loc[i, 'championnat_nbmatchs'])
            df_temp.loc[i, 'xG_Away'] = attack * defense * (df_temp.loc[i, 'buts_championnat_away'] / df_temp.loc[i, 'championnat_nbmatchs'])
        except:
            print('... erreur', i)

    return df_temp
